function trainingConvergence(status)

    if(status == 1)
        fprintf('Training Converged\n');
    end

end